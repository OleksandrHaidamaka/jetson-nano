/*******************************************************************************#
#           guvcview              http://guvcview.sourceforge.net               #
#                                                                               #
#           Paulo Assis <pj.assis@gmail.com>                                    #
#           Nobuhiro Iwamatsu <iwamatsu@nigauri.org>                            #
#                             Add UYVY color support(Macbook iSight)            #
#           George Sedov <radist.morse@gmail.com>                               #
#                             Threaded encoding                                 #
#                             default action selector for Webcam button         #
#                                                                               #
# This program is free software; you can redistribute it and/or modify          #
# it under the terms of the GNU General Public License as published by          #
# the Free Software Foundation; either version 2 of the License, or             #
# (at your option) any later version.                                           #
#                                                                               #
# This program is distributed in the hope that it will be useful,               #
# but WITHOUT ANY WARRANTY; without even the implied warranty of                #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
# GNU General Public License for more details.                                  #
#                                                                               #
# You should have received a copy of the GNU General Public License             #
# along with this program; if not, write to the Free Software                   #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     #
#                                                                               #
********************************************************************************/

#ifndef GUVCVIEW_H
#define GUVCVIEW_H

#include "v4l2uvc.h"
#include "sound.h"
#include "autofocus.h"
#include "video_format.h"

#if 1

enum{
	CLOCK_ERROR			= 0,
	SEQUENCE_MONITOR_ERROR		= 1, 
	SYNC_MONITOR_ERROR		= 2,
	DUAL_TEMP_ERROR1		= 3,
	DUAL_TEMP_ERROR2		= 4,
	DUAL_TEMP_ERROR3		= 5,
	SRAM_ECC_ERROR1			= 6,
	SRAM_ECC_ERROR2			= 7,
	SRAM_ECC_ERROR3			= 8,
	OTP_CRC_ERROR1			= 9,
	OTP_CRC_ERROR2			= 10,
	OTP_CRC_ERROR3			= 11,
	OTP_CRC_ERROR4			= 12,
	OTP_CRC_ERROR5			= 13,
	OTP_CRC_ERROR6			= 14,
	ROM_CRC_ERROR1			= 15,
	ROM_CRC_ERROR2			= 16,
	ROM_CRC_ERROR3			= 17,
	ABIST_CHECK_ERROR		= 18,
	DATA_PATH_TEST_ERROR		= 19,
	REGISTER_MONITOR_ERROR		= 20,
	DUAL_LOCK_MONITOR_ERROR		= 21,
	INTERNAL_BUS_ERROR		= 23,
	ROW_COLUMN_ID_CHECK_ERROR	= 24,
	POWER_MONITOR_ERROR1		= 25,
	POWER_MONITOR_ERROR2		= 26,
	POWER_MONITOR_ERROR3		= 27,
	WWDG_TIMER_ERROR		= 28,
	FLASH_CHECK_ERROR1		= 29,
	FLASH_CHECK_ERROR2		= 30,
	FLASH_CHECK_ERROR3		= 31,
	CONTROL_FLOW_MONITOR_ERROR	= 32,
	DMAC_MONITOR_ERROR		= 33,
	POWER_SWITCH_MONITOR_ERROR	= 34,
	CCC_PEELING_CHECK_ERROR		= 35,
	MEMORY_PROTECTION_ERROR		= 36,
	LBIST_CHECK_ERROR		= 37,
	MBIST_CHECK_ERROR		= 38,
	COMMUNICATION_CRC_ERROR		= 39,
};




#endif



/* Must set this as global so they */
/* can be set from any callback.   */

struct GWIDGET
{
	/* The main window*/
	GtkWidget *mainwin;
	/* A restart Dialog */
	GtkWidget *restartdialog;
	/*Paned containers*/
	GtkWidget *maintable;
	GtkWidget *boxh;

	//group list for menu video codecs
	GSList *vgroup;
	//group list for menu audio codecs
	GSList *agroup;

	//menu top widgets
	GtkWidget *menu_photo_top;
	GtkWidget *menu_video_top;
	//Increment Image Filename (menu item)
	GtkWidget *photo_timestamp;

	GtkWidget *status_bar;

	GtkWidget *label_SndAPI;
	GtkWidget *SndAPI;
	GtkWidget *SndEnable;
	GtkWidget *SndSampleRate;
	GtkWidget *SndDevice;
	GtkWidget *SndNumChan;
	GtkWidget *SndComp;
	/*must be called from main loop if capture timer enabled*/
	GtkWidget *ImageType;
	GtkWidget *CapImageButt;
	GtkWidget *CapVidButt;
	GtkWidget *AboutButt;
	GtkWidget *Resolution;
	GtkWidget *InpType;
	GtkWidget *FrameRate;
	GtkWidget *Devices;
	GtkWidget *jpeg_comp;
	GtkWidget *quitButton;

	gboolean vid_widget_state;
	int status_warning_id;
};

/* uvc H264 control widgets */
struct uvc_h264_gtkcontrols
{
	GtkWidget* FrameInterval;
	GtkWidget* BitRate;
	GtkWidget* Hints_res;
	GtkWidget* Hints_prof;
	GtkWidget* Hints_ratecontrol;
	GtkWidget* Hints_usage;
	GtkWidget* Hints_slicemode;
	GtkWidget* Hints_sliceunit;
	GtkWidget* Hints_view;
	GtkWidget* Hints_temporal;
	GtkWidget* Hints_snr;
	GtkWidget* Hints_spatial;
	GtkWidget* Hints_spatiallayer;
	GtkWidget* Hints_frameinterval;
	GtkWidget* Hints_leakybucket;
	GtkWidget* Hints_bitrate;
	GtkWidget* Hints_cabac;
	GtkWidget* Hints_iframe;
	GtkWidget* Resolution;
	GtkWidget* SliceUnits;
	GtkWidget* SliceMode;
	GtkWidget* Profile;
	GtkWidget* Profile_flags;
	GtkWidget* IFramePeriod;
	GtkWidget* EstimatedVideoDelay;
	GtkWidget* EstimatedMaxConfigDelay;
	GtkWidget* UsageType;
	//GtkWidget* UCConfig;
	GtkWidget* RateControlMode;
	GtkWidget* RateControlMode_cbr_flag;
	GtkWidget* TemporalScaleMode;
	GtkWidget* SpatialScaleMode;
	GtkWidget* SNRScaleMode;
	GtkWidget* StreamMuxOption;
	GtkWidget* StreamMuxOption_aux;
	GtkWidget* StreamMuxOption_mjpgcontainer;
	GtkWidget* StreamFormat;
	GtkWidget* EntropyCABAC;
	GtkWidget* Timestamp;
	GtkWidget* NumOfReorderFrames;
	GtkWidget* PreviewFlipped;
	GtkWidget* View;
	GtkWidget* StreamID;
	GtkWidget* SpatialLayerRatio;
	GtkWidget* LeakyBucketSize;
	GtkWidget* probe_button;
	GtkWidget* commit_button;
};

struct ALL_DATA
{
	struct paRecordData *pdata;
	struct GLOBAL *global;
	struct focusData *AFdata;
	struct vdIn *videoIn;
	struct VideoFormatData *videoF;
	struct GWIDGET *gwidget;
	struct uvc_h264_gtkcontrols  *h264_controls;
	struct VidState *s;
//Start of e-con
	struct xunit *HIDdata;
//End of e-con
	__THREAD_TYPE video_thread;
	__THREAD_TYPE audio_thread;
	__THREAD_TYPE IO_thread;
};

#endif
