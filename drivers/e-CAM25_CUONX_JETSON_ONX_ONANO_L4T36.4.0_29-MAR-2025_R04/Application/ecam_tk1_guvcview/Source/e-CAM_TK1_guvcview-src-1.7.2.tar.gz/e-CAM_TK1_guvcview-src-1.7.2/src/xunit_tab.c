/*******************************************************************************#
#           guvcview              http://guvcview.sourceforge.net               #
#                                                                               #
#           Paulo Assis <pj.assis@gmail.com>                                    #
#           Nobuhiro Iwamatsu <iwamatsu@nigauri.org>                            #
#                                                                               #
#                                                                               #
# This program is free software; you can redistribute it and/or modify          #
# it under the terms of the GNU General Public License as published by          #
# the Free Software Foundation; either version 2 of the License, or             #
# (at your option) any later version.                                           #
#                                                                               #
# This program is distributed in the hope that it will be useful,               #
# but WITHOUT ANY WARRANTY; without even the implied warranty of                #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
# GNU General Public License for more details.                                  #
#                                                                               #
# You should have received a copy of the GNU General Public License             #
# along with this program; if not, write to the Free Software                   #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     #
#                                                                               #
********************************************************************************/

#include <SDL/SDL.h>
#include <glib.h>
#include <glib/gprintf.h>
/* support for internationalization - i18n */
#include <glib/gi18n.h>
#include <gtk/gtk.h>
#include "globals.h"
#include "callbacks.h"
#include "v4l2uvc.h"
#include "string_utils.h"
#include "vcodecs.h"

#include "xunit_tab.h"



void ShowAbout(GtkButton *AboutButt, struct ALL_DATA *all_data)
{
	gchar* econLogoPath = g_strconcat (PACKAGE_DATA_DIR,"/pixmaps/guvcview/econ_icon.png",NULL);
	//don't test for file - use default empty image if load fails
	//get icon image
	GdkPixbuf *econLogo = gdk_pixbuf_new_from_file(econLogoPath,NULL);
	g_free(econLogoPath);

	GtkWidget *AboutDialog = gtk_about_dialog_new();
	gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG (AboutDialog), "e-CAM_TK1 GUVCViewer");
	gtk_about_dialog_set_version(GTK_ABOUT_DIALOG (AboutDialog), PACKAGE_VERSION);
	gtk_about_dialog_set_copyright(GTK_ABOUT_DIALOG (AboutDialog), "Copyright © 2016 e-con Systems");
	gtk_about_dialog_set_comments(GTK_ABOUT_DIALOG (AboutDialog),
		"This program ecam_tk1_guvcview is a free software distributed under GNU GPL. With full credits to the original contributor (guvcview.sourceforge.net) this program is a custom version to support e-con's Embedded Cameras for the Jetson and its controls.");
	gtk_about_dialog_set_website(GTK_ABOUT_DIALOG (AboutDialog),
		"http://www.e-consystems.com");
	gtk_about_dialog_set_website_label(GTK_ABOUT_DIALOG (AboutDialog),
		"e-consystems");
	gtk_about_dialog_set_logo(GTK_ABOUT_DIALOG (AboutDialog), econLogo);

	gtk_widget_show(AboutDialog);
	gtk_dialog_run (GTK_DIALOG (AboutDialog));
	gtk_widget_destroy(AboutDialog);
	return;
}

