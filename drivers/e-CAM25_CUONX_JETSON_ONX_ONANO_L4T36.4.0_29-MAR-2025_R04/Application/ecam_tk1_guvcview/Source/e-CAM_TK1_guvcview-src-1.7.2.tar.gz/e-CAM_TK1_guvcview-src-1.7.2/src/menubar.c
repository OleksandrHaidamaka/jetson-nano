/*******************************************************************************#
#           guvcview              http://guvcview.sourceforge.net               #
#                                                                               #
#           Paulo Assis <pj.assis@gmail.com>                                    #
#           Nobuhiro Iwamatsu <iwamatsu@nigauri.org>                            #
#           Dr. Alexander K. Seewald <alex@seewald.at>                          #
#                             Autofocus algorithm                               #
#           Flemming Frandsen <dren.dk@gmail.com>                               #
#           George Sedov <radist.morse@gmail.com>                               #
#                                                                               #
# This program is free software; you can redistribute it and/or modify          #
# it under the terms of the GNU General Public License as published by          #
# the Free Software Foundation; either version 2 of the License, or             #
# (at your option) any later version.                                           #
#                                                                               #
# This program is distributed in the hope that it will be useful,               #
# but WITHOUT ANY WARRANTY; without even the implied warranty of                #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
# GNU General Public License for more details.                                  #
#                                                                               #
# You should have received a copy of the GNU General Public License             #
# along with this program; if not, write to the Free Software                   #
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA     #
#                                                                               #
********************************************************************************/

#include <glib.h>
#include <glib/gprintf.h>
/* support for internationalization - i18n */
#include <glib/gi18n.h>
/* locale.h is needed if -O0 used (no optimiztions)  */
/* otherwise included from libintl.h on glib/gi18n.h */
#include <locale.h>
#include <gtk/gtk.h>

#include "../config.h"
#include "string_utils.h"
#include "options.h"
#include "vcodecs.h"
#include "acodecs.h"
#include "callbacks.h"

GtkWidget *create_menu(struct ALL_DATA *all_data, int control_only)
{
	struct GLOBAL *global = all_data->global;
	struct GWIDGET *gwidget = all_data->gwidget;

	GtkWidget *menubar;

	GtkWidget *controls_menu;
	GtkWidget *controls_top;
	GtkWidget *controls_load;
	GtkWidget *controls_save;
	GtkWidget *controls_default;

	menubar = gtk_menu_bar_new();
	gtk_menu_bar_set_pack_direction(GTK_MENU_BAR(menubar), GTK_PACK_DIRECTION_LTR);

	controls_menu = gtk_menu_new();

	//controls menu
	controls_top = gtk_menu_item_new_with_label(_("Settings"));
	controls_load = gtk_menu_item_new_with_label(_("Load Profile"));
	controls_save = gtk_menu_item_new_with_label(_("Save Profile"));
	controls_default = gtk_menu_item_new_with_label(_("Hardware Defaults"));

	gtk_widget_show (controls_top);
	gtk_widget_show (controls_load);
	gtk_widget_show (controls_save);
	gtk_widget_show (controls_default);

	g_object_set_data (G_OBJECT (controls_save), "profile_dialog", GINT_TO_POINTER(1));
	g_signal_connect (GTK_MENU_ITEM(controls_save), "activate",
		G_CALLBACK (Profile_clicked), all_data);
	g_object_set_data (G_OBJECT (controls_load), "profile_dialog", GINT_TO_POINTER(0));
	g_signal_connect (GTK_MENU_ITEM(controls_load), "activate",
		G_CALLBACK (Profile_clicked), all_data);
	g_signal_connect (GTK_MENU_ITEM(controls_default), "activate",
		G_CALLBACK (Defaults_clicked), all_data);

	gtk_menu_item_set_submenu(GTK_MENU_ITEM(controls_top), controls_menu);
	gtk_menu_shell_append(GTK_MENU_SHELL(controls_menu), controls_load);
	gtk_menu_shell_append(GTK_MENU_SHELL(controls_menu), controls_save);
	gtk_menu_shell_append(GTK_MENU_SHELL(controls_menu), controls_default);
	gtk_menu_shell_append(GTK_MENU_SHELL(menubar), controls_top);

	if(!control_only) /*control_only exclusion */
	{
		GtkWidget *photo_menu;
		//GtkWidget *photo_top;
		GtkWidget *photo_file;

		photo_menu = gtk_menu_new();

		//photo menu
		gwidget->menu_photo_top = gtk_menu_item_new_with_label(_("Photo"));
		photo_file = gtk_menu_item_new_with_label(_("File"));
		gwidget->photo_timestamp = gtk_check_menu_item_new_with_label(_("Increment Filename"));

		gtk_widget_show (gwidget->menu_photo_top);
		gtk_widget_show (photo_file);
		gtk_widget_show (gwidget->photo_timestamp);

		/** flag the file dialog as image file*/
		g_object_set_data (G_OBJECT (photo_file), "file_butt", GINT_TO_POINTER(0));
		g_signal_connect (GTK_MENU_ITEM(photo_file), "activate",
			G_CALLBACK (file_chooser), all_data);

		/** add callback to Append timestamp */
		gtk_check_menu_item_set_active (GTK_CHECK_MENU_ITEM (gwidget->photo_timestamp), (global->image_inc > 0));
		g_signal_connect (GTK_CHECK_MENU_ITEM(gwidget->photo_timestamp), "toggled",
			G_CALLBACK (image_prefix_toggled), all_data);

		gtk_menu_item_set_submenu(GTK_MENU_ITEM(gwidget->menu_photo_top), photo_menu);
		gtk_menu_shell_append(GTK_MENU_SHELL(photo_menu), photo_file);
		gtk_menu_shell_append(GTK_MENU_SHELL(photo_menu), gwidget->photo_timestamp);
		gtk_menu_shell_append(GTK_MENU_SHELL(menubar), gwidget->menu_photo_top);
	}

	gtk_widget_show (menubar);
	gtk_container_set_resize_mode (GTK_CONTAINER(menubar), GTK_RESIZE_PARENT);
	return menubar;
}
